var rules = {
    'import/no-extraneous-dependencies': 0,
};

module.exports = {
    rules: rules,
};
