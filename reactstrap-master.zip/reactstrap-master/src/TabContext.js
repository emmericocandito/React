import React from 'react';

/**
 * TabContext
 * {
 *  activeTabId: PropTypes.any
 * }
 */
export const TabContext = React.createContext({});