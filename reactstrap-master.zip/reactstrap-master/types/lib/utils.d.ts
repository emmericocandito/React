import { CSSModule } from './index';

export function setGlobalCssModule(cssModule: CSSModule): void;
