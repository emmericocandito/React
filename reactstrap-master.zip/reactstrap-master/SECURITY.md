# Security Policy

## Supported Versions

Currently, only the latest version is supported.

## Reporting a Vulnerability

### Security contact information

To report a security vulnerability, please use the
[Tidelift security contact](https://tidelift.com/security).
Tidelift will coordinate the fix and disclosure.
