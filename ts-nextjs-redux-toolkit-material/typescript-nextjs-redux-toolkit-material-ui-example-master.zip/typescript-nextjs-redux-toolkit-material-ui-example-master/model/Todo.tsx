/**
 * TODO model
 */
export type Todo = {
  id: number
  name: string
  complete: boolean
  createdAt: Date
  updatedAt: Date
}
