export enum SiteInfo {
  SITE_NAME = "Sample site",
}
