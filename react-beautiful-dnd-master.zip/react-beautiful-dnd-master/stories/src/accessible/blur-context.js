// @flow
import React from 'react';

const BlurContext = React.createContext<number>(0);

export default BlurContext;
