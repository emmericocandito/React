// @flow
export { default } from './use-style-marshal';
