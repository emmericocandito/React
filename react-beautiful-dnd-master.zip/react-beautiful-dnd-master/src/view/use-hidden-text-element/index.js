// @flow
export { default } from './use-hidden-text-element';
