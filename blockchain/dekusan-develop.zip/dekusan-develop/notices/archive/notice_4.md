Dear DekuSan Users,

There have been several instances of high-profile legitimate websites such as BTC Manager and Games Workshop that have had their websites temporarily compromised. This involves showing a fake DekuSan window on the page asking for user's seed phrases. DekuSan will never open itself in this way and users are encouraged to report these instances immediately to either [our phishing blacklist](https://github.com/dexon-foundation/dekusan/issues) or our support email at [support@dexon.org](mailto:support@dexon.org).

Please read the full article on this ongoing issue at [https://medium.com/metamask/new-phishing-strategy-becoming-common-1b1123837168](https://medium.com/metamask/new-phishing-strategy-becoming-common-1b1123837168). 

