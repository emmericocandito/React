DekuSan is beta software. 

When you log in to DekuSan, your current account's address is visible to every new site you visit. This can be used to look up your account balances of Ether and other tokens.

For your privacy, for now, please sign out of DekuSan when you're done using a site.

