# Notices

Those notices are of legal nature. They are displayed to the users of DekuSan.

Any changes or additions must be reviewed by the product management.