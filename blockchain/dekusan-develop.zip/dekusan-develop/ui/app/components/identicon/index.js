export { default } from './identicon.container'
