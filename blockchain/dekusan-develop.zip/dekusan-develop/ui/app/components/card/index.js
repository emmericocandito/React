export { default } from './card.component'
