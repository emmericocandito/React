export { default } from './jazzicon.component'
