export { default } from './hex-to-decimal.component'
