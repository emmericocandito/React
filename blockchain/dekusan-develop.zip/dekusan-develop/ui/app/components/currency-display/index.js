export { default } from './currency-display.container'
