export { default } from './confirm-page-container-header.component'
