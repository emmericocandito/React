export { default } from './confirm-page-container-warning.component'
