import Button from './button.component'
module.exports = Button
