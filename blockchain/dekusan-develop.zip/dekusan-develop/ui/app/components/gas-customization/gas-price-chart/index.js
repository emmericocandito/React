export { default } from './gas-price-chart.component'
