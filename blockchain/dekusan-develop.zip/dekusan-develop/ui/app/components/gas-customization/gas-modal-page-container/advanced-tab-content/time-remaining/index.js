export { default } from './time-remaining.component'
