export { default } from './basic-tab-content.component'
