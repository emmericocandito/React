export { default } from './button-group.component'
