# Running UI Dev Mode

You can run `npm run ui`, and your browser should open a live-reloading demo version of the plugin UI.

Some actions will crash the app, so this is only for tuning aesthetics, but it allows live-reloading styles, which is a much faster feedback loop than reloading the full extension.

