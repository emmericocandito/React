### Developing on UI with Mocked Background Process

You can run `npm run mock` and your browser should open a live-reloading demo version of the plugin UI, just like the `npm run ui`, except that it tries to actually perform all normal operations.

It does not yet connect to a real blockchain (this could be a good test feature later, connecting to a test blockchain), so only local operations work.

You can reset the mock ui at any time with the `Reset` button at the top of the screen.

