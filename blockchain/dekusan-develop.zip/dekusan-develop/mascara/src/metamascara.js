global.dekusan = require('metamascara')
