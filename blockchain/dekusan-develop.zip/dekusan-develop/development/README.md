# Development

Several files which are needed for developing on(!) DekuSan.

Usually each files contains information about its scope / usage.