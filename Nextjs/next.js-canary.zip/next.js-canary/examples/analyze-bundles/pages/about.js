export default function About() {
  return <div>About us</div>
}
