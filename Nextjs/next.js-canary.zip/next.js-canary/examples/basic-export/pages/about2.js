export default function About2() {
  return <div>About 2</div>
}
