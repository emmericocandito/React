---
title: "The Passing of the Grey Company"
excerpt: "Aragorn, Legolas, and Gimli are accompanied by the Grey Company as
they pass through the Paths of the Dead between Rohan and Gondor."
date: "2021-01-22"
---

Placeat consequuntur ullam aut sapiente illo velit. Eius facere ut molestias
totam laborum pariatur quam. Praesentium quo veritatis expedita animi.

Quite anything glass benefit. Such form clearly top tend can require my. Federal
degree sort performance region maintain.

Ut dignissimos sapiente culpa rerum pariatur consequatur. Corporis suscipit ad
corrupti aut. Expedita culpa aut deleniti officiis.

Porro eum id sit quia expedita. Alias expedita asperiores. Corporis ex eum atque
cum ea.
