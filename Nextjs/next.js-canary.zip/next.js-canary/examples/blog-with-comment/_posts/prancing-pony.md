---
title: "At the Sign of the Prancing Pony"
excerpt: "The Hobbits reach the The Prancing Pony inn at Bree, where Frodo uses
a false name, Underhill."
date: "2021-03-03"
---

Placeat consequuntur ullam aut sapiente illo velit. Eius facere ut molestias
totam laborum pariatur quam. Praesentium quo veritatis expedita animi.

Quite anything glass benefit. Such form clearly top tend can require my. Federal
degree sort performance region maintain.

Ut dignissimos sapiente culpa rerum pariatur consequatur. Corporis suscipit ad
corrupti aut. Expedita culpa aut deleniti officiis.

Porro eum id sit quia expedita. Alias expedita asperiores. Corporis ex eum atque
cum ea.
