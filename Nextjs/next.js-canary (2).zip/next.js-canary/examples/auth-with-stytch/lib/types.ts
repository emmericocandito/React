export enum LoginMethod {
  API,
  SDK,
}
