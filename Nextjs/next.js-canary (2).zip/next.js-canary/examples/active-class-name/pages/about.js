import Nav from '../components/Nav'

const AboutPage = () => (
  <>
    <Nav />
    <p>Hello, I'm the about page</p>
  </>
)

export default AboutPage
