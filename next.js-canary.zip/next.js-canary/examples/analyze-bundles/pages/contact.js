export default function Contact() {
  return <div>This is the contact page.</div>
}
