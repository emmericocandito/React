# next.config.js Loading Error

#### Why This Error Occurred

When attempting to load your `next.config.js` or `next.config.mjs` file, an error occurred. This could be due to a syntax error or attempting to `require`/`import` a module that wasn't available.

#### Possible Ways to Fix It

See the error message in your terminal where you started `next` to see more context.

> Note: This config file is not transpiled by Next.js, so only use features supported by your current Node.js version.

### Useful Links

- [next.config.js documentation](https://nextjs.org/docs/api-reference/next.config.js/introduction)
- [Node.js version feature chart](https://node.green/)
