# SWC minify enabled

#### Why This Message Occurred

The application has enabled `swcMinify` in `next.config.js`. By opting in minification will happen using the [SWC](https://swc.rs) minifier instead of Terser. This new minifier is 7x faster than Terser with comparable output. We're actively working on optimizing the output size and minification speed further.

If you have feedback about the minification, please provide it on [the feedback thread](https://github.com/vercel/next.js/discussions/30237).
