# "next/jest" Experimental

#### Why This Message Occurred

You are using `next/jest` which is currently an experimental feature of Next.js. In a future version of Next.js `next/jest` will be marked as stable.

If you have any feedback about the transformer you can share it on this discussion: https://github.com/vercel/next.js/discussions/31152.
