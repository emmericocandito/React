export const LIMIT = 10;
export const SUPER_ADMIN = "super_admin";
