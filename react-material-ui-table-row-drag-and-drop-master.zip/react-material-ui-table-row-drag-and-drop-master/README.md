# react-material-ui-table-row-drag-and-drop
Drag and drop for table rows using react, material-ui, beautiful-dnd

To run the example use: 
```
npm install
npm start
```
The interesting bits are in src/index.js

This example is based on the following sources:
https://github.com/atlassian/react-beautiful-dnd/blob/master/docs/about/examples.md
https://codesandbox.io/s/k260nyxq9v
https://stackoverflow.com/questions/51839298/use-material-ui-table-with-react-beautiful-dnd
https://material-ui.com/components/tables/

Special thanks to
https://stackoverflow.com/users/4965713/bryant
